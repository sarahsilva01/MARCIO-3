package com.example.mcqueen

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
